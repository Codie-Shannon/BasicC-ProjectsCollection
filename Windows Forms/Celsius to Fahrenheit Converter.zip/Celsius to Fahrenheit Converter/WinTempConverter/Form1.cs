﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinTempConverter
{
    public partial class Form1 : Form
    {

        double usernum;

        public Form1()
        {
            InitializeComponent();
        }

        private void Txtconvert_Click(object sender, EventArgs e)
        {
            Invalid.Visible = false;

           usernum = Convert.ToInt32(txtcelnum.Text);

            if(usernum >= 1)
            {
                if(usernum <= 100)
                {
                        usernum = usernum * 9 / 5 + 32;

                        txtfahnum.Text = usernum.ToString();
                }
                else
                {
                    Invalid.Visible = true;
                }
            }
            else
            {
                Invalid.Visible = true;
            }
        }
    }
}
