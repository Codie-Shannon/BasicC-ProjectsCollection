﻿namespace WinTempConverter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtcel = new System.Windows.Forms.TextBox();
            this.txtfah = new System.Windows.Forms.TextBox();
            this.txtfahnum = new System.Windows.Forms.TextBox();
            this.txtcelnum = new System.Windows.Forms.TextBox();
            this.txtconvert = new System.Windows.Forms.Button();
            this.Invalid = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtcel
            // 
            this.txtcel.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtcel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcel.Location = new System.Drawing.Point(62, 37);
            this.txtcel.Name = "txtcel";
            this.txtcel.ReadOnly = true;
            this.txtcel.Size = new System.Drawing.Size(100, 15);
            this.txtcel.TabIndex = 0;
            this.txtcel.TabStop = false;
            this.txtcel.Text = "Celsius";
            this.txtcel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtfah
            // 
            this.txtfah.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtfah.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfah.Location = new System.Drawing.Point(271, 37);
            this.txtfah.Name = "txtfah";
            this.txtfah.ReadOnly = true;
            this.txtfah.Size = new System.Drawing.Size(100, 15);
            this.txtfah.TabIndex = 1;
            this.txtfah.TabStop = false;
            this.txtfah.Text = "Fahrenheit";
            this.txtfah.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtfahnum
            // 
            this.txtfahnum.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtfahnum.Location = new System.Drawing.Point(271, 65);
            this.txtfahnum.Name = "txtfahnum";
            this.txtfahnum.ReadOnly = true;
            this.txtfahnum.Size = new System.Drawing.Size(100, 15);
            this.txtfahnum.TabIndex = 3;
            this.txtfahnum.TabStop = false;
            this.txtfahnum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtcelnum
            // 
            this.txtcelnum.Location = new System.Drawing.Point(62, 65);
            this.txtcelnum.Name = "txtcelnum";
            this.txtcelnum.Size = new System.Drawing.Size(100, 22);
            this.txtcelnum.TabIndex = 2;
            // 
            // txtconvert
            // 
            this.txtconvert.Location = new System.Drawing.Point(181, 65);
            this.txtconvert.Name = "txtconvert";
            this.txtconvert.Size = new System.Drawing.Size(75, 23);
            this.txtconvert.TabIndex = 4;
            this.txtconvert.Text = "Convert";
            this.txtconvert.UseVisualStyleBackColor = true;
            this.txtconvert.Click += new System.EventHandler(this.Txtconvert_Click);
            // 
            // Invalid
            // 
            this.Invalid.AutoSize = true;
            this.Invalid.Location = new System.Drawing.Point(22, 107);
            this.Invalid.Name = "Invalid";
            this.Invalid.Size = new System.Drawing.Size(382, 17);
            this.Invalid.TabIndex = 5;
            this.Invalid.Text = "That Was Invalid Please Try Again With A Different Number";
            this.Invalid.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(425, 133);
            this.Controls.Add(this.Invalid);
            this.Controls.Add(this.txtconvert);
            this.Controls.Add(this.txtfahnum);
            this.Controls.Add(this.txtcelnum);
            this.Controls.Add(this.txtfah);
            this.Controls.Add(this.txtcel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Celsius Degrees To Fahrenheit Converter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtcel;
        private System.Windows.Forms.TextBox txtfah;
        private System.Windows.Forms.TextBox txtfahnum;
        private System.Windows.Forms.TextBox txtcelnum;
        private System.Windows.Forms.Button txtconvert;
        private System.Windows.Forms.Label Invalid;
    }
}

