﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1Question1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Book object
            Book book1 = new Book();

            //Ask user to enter new book details below
            Console.WriteLine("*** ENTER NEW BOOK DETAILS BELOW ***");

            //Ask user for book title
            Console.Write("\nEnter Book Title: ");

            //Assign book title
            book1.SetTitle(Console.ReadLine());

            //Ask user for book author
            Console.Write("Enter Book Author: ");

            //Assign book author
            book1.SetAuthor(Console.ReadLine());

            //Ask user for book publisher
            Console.Write("Enter Book Publisher: ");

            //Assign book publisher
            book1.SetPublisher(Console.ReadLine());

            //Display gathered information back to user
            Console.WriteLine("\n******************************************");
            Console.WriteLine("The following new book has been processed:");
            Console.WriteLine("Book Title: {0}", book1.GetTitle());
            Console.WriteLine("Auther: {0}", book1.GetAuthor());
            Console.WriteLine("Publisher: {0}", book1.GetPublisher());

            //Inform user of how to close the application
            Console.Write("\nPlease press any key to close the application.");

            //Await key press
            Console.ReadKey();
        }
    }
}
