﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1Question1
{
    class Book
    {
        //Instance Variables
        private string title;
        private string author;
        private string publisher;

        public string GetTitle()
        {
            //Return Title
            return title;
        }

        public void SetTitle(string tle)
        {
            //Set Title
            title = tle;
        }

        public string GetAuthor()
        {
            //Return Author
            return author;
        }

        public void SetAuthor(string au)
        {
            //Set Author
            author = au;
        }

        public string GetPublisher()
        {
            //Return Publisher
            return publisher;
        }

        public void SetPublisher(string pub)
        {
            //Set Publisher
            publisher = pub;
        }
    }
}
