﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1Question5
{
    class Driver : Employee
    {
        //Auto Implemented Properties
        public string Vehicle { get; set; }
        public string DriversLicenseNo { get; set; }

        public Driver(string firstName, string lastName, string vehicle)
        {
            //Inform the user of the vehicle the employee is driving
            Console.WriteLine("Adding Employee as a new Driver to Drive {0}...", vehicle);

            //Assigning variables
            Vehicle = vehicle;
            FirstName = firstName;
            LastName = lastName;
        }

        public string ProcessDriver()
        {
            //Return gathered information to user
            return ("\n" + "The following empolyee details have been Entered:" + "\n" + "Driver name: " + GetFullName() + "\n" + "Drivers licence No: " + DriversLicenseNo + "\n" + "Vehicle: " + Vehicle);
        }
    }
}
