﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1Question5
{
    class Program
    {
        static void Main(string[] args)
        {
            //Driver Object
            Driver driver = new Driver("John", "Doe", "Van");

            //Ask the user for employee license number
            Console.Write("\nPlease enter license number for this employee: ");

            //Assign license number
            driver.DriversLicenseNo = Console.ReadLine();

            //Display gathered information to user
            Console.WriteLine(driver.ProcessDriver());

            //Inform the user of how to close the application
            Console.Write("\nPress any key to exit the program.");

            //Await key press
            Console.ReadKey();
        }
    }
}
