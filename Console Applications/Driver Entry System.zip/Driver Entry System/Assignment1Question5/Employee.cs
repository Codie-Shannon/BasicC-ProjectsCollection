﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1Question5
{
    class Employee
    {
        //Auto Implemented Properties
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int YearStarted { get; set; }

        public Employee()
        {
            //Inform the user that the application is creating a new employee record
            Console.WriteLine("Creating new Employee record...");
        }

        public string GetFullName()
        {
            //Return full name
            return FirstName + " " + LastName;
        }

        public int GetYearsWorked()
        {
            //Return years worked
            return DateTime.Now.Year - YearStarted;
        }
    }
}
