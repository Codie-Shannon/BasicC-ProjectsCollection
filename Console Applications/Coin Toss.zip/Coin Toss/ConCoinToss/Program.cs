﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConCoinToss
{
    class Program
    {
        static void Main(string[] args)
        {

            //VARIABLES
            Random random = new Random();
            int chances;
            string heads = "\nHeads";
            string tails = "\nTails";
            int timer;
            int retries;
            int placeholder0 = 0;
            int placeholder1 = 0;
            int placeholder2 = 0;

            for (retries = 0; retries <= 2; retries += 1)
            {
                if(retries == 0)
                {
                    Console.Write("Press any key to toss the coin");
                }
                else
                {
                    Console.Write("\n\nPress any key to toss the coin");
                }

                Console.ReadKey();

                for (timer = 0; timer <= 2; timer += 1)
                {
                    chances = random.Next(1, 3);

                    if (placeholder0 == 0)
                    {
                        placeholder0 += chances;
                    }
                    else if (placeholder1 == 0)
                    {
                        placeholder1 += chances;
                    }
                    else
                    {
                        placeholder2 += chances;
                    }
                }

                //displaying and testing the numbers to see what they were doing
                //Console.WriteLine("\n" + placeholder0 + "\n" + placeholder1 + "\n" + placeholder2);

                placeholder2 += placeholder1 += placeholder0;

                if (placeholder2 == 6)
                {
                    //heads won
                    Console.Write(heads);
                }
                else if (placeholder2 == 4)
                {
                    //tails won
                    Console.Write(heads);
                }
                else if (placeholder2 == 5)
                {
                    //tails won
                    Console.Write(tails);
                }
                else if (placeholder2 == 3)
                {
                    //tails won
                    Console.Write(tails);
                }

                placeholder0 = 0;
                placeholder1 = 0;
                placeholder2 = 0;
            }

            Console.ReadKey();
        }
    }
}
