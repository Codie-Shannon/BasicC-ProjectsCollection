﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3Question2
{
    class Program
    {
        static void Main(string[] args)
        {
            //This program will create two hardcoded matrices and display them back to the user with a solution matrix"
            //By Codie Shannon
            //================================================================================================================================//

            //Variables
            string spacer = "================";
            int[,] A = new int[2, 3]
            {
                { 3, 6, 2 },
                { 5, 4, 4 }
            };
            int[,] B = new int[2, 3]
            {
                { 8, 2, 10 },
                { 6, 3, 6 }
            };
            int[,] C = new int[2, 3];

            //Inform the user of the applications purpose
            Console.WriteLine("This program will create two hardcoded matrices and display them back to you with a solution matrix.");

            //Spacer
            Console.WriteLine("====================================================================================================");

            //Outer loop to iterate through the rows
            for (int i = 0; i < 2; i++)
            {
                //Inner loop to iterate through the columns
                for (int j = 0; j < 3; j++)
                {
                    //Adding A and B and assigning into C
                    C[i, j] = A[i, j] + B[i, j];
                }
            }

            //Run DisplayLoop Method To Display Matrix A
            DisplayLoop("A =", A);

            //Spacer
            Console.WriteLine(spacer);

            //Run DisplayLoop Method To Display Matrix B
            DisplayLoop("B =", B);

            //Spacer
            Console.WriteLine(spacer);

            //Run DisplayLoop Method To Display Solution Matrix
            DisplayLoop("Solution Matrix", C);

            //Spacer
            Console.WriteLine("==============================================");

            //Inform user of how to close the application
            Console.Write("Please press any key to close the application.");

            //Await key press
            Console.ReadKey();
        }

        static void DisplayLoop(string Display, int[,] Letter)
        {
            //Display assigned mesage
            Console.WriteLine(Display);

            //Outer loop to iterate through the rows
            for (int i = 0; i < 2; i++)
            {
                //Inner loop to iterate through the columns
                for (int j = 0; j < 3; j++)
                {
                    //This is used to display the assigned numbers
                    Console.Write(Letter[i, j] + " ");
                }

                //Creating new line
                Console.WriteLine();
            }
        }
    }
}
