﻿using Assignment1_Question3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace Assignment1_Question4
{
	class Program
	{
		//Local variables
		static string purpose = "This program will display a list of customers, ask you to enter three IDs, then return the customers data.";
		static string spacer = "==========================================================================================================";

		static void Main(string[] args)
		{
			//This program was created by Codie Shannon
			//This program will display five customers to the user, ask the user to pick three customers, and display the three customers back to them
			//Using MyQueue, a List and Tuples

			//Local variables
			MyQueue queue = new MyQueue();

			//Used for creation of Tuples https://stackoverflow.com/a/19353995
			List<Tuple<int, string, int>> customers = new List<Tuple<int, string, int>>()
			{
				Tuple.Create(1, "Poppa", 5),
				Tuple.Create(2, "Dr Dave", 2),
				Tuple.Create(3, "Grandma", 8),
				Tuple.Create(4, "Bobby", 3),
				Tuple.Create(5, "Farmer Joe", 6)
			};

			//Inform user of applications purpose
			Console.WriteLine(purpose);
			Console.WriteLine(spacer);

			//Display Menu
			DisplayMenu(queue, customers);

			//Clear Console
			Console.Clear();

			//Display Customers
			DisplayCustomers(queue, customers);

			//Spacer
			Console.WriteLine(spacer);

			//Inform user of how to close the application
			Console.Write("Please press any key to close the application.");

			//Await key press
			Console.ReadKey();
		}

		static void DisplayMenu(MyQueue queue, List<Tuple<int, string, int>> customers)
		{
			//Loop until three items have been added to the queue object
			while (queue.Length < 3)
			{
				//Display labels
				Console.WriteLine("ID\tCustomer\tProcessing Time");
				Console.WriteLine(spacer);

				//Loop through each item in the customers list
				foreach (Tuple<int, string, int> customer in customers)
				{
					//Display current looped customer to screen
					Console.WriteLine($"{customer.Item1}\t{customer.Item2}\t\t{customer.Item3} seconds");
				}

				//Spacer
				Console.WriteLine(spacer);

				//Get id from user
				Console.Write("Enter the ID of the customer: ");
				int id = Convert.ToInt32(Console.ReadLine());

				//Check if the customers list contains the id
				if (customers.Any(i => i.Item1 == id))
				{
					//Add id to queue
					queue.Enqueue(id);
				}
				else
				{
					Console.WriteLine("The menu does not contain that value, please enter a valid value.");
				}
			}
		}

		static void DisplayCustomers(MyQueue queue, List<Tuple<int, string, int>> customers)
		{
			//Local variables
			int processtime = 0;

			//Inform user of applications purpose
			Console.WriteLine(purpose);
			Console.WriteLine(spacer);

			//Display labels
			Console.WriteLine("ID\tCustomer\tProcessing Time");
			Console.WriteLine(spacer);

			//Loop until the queue's length is 0
			while (queue.Length > 0)
			{
				//Get the top customer ID from the queue
				int id = Convert.ToInt32(queue.Dequeue());

				//Get customer from customers list
				Tuple<int, string, int> customer = customers.Single(i => i.Item1 == id);

				//Stop thread for x amount of seconds based on previous customers processing time
				Thread.Sleep(processtime);

				//Check if the current looped customer is bobby and the queue length is above 0 
				if (customer.Item2 == "Bobby" && queue.Length > 0)
				{
					//Display message saying that bobby had to go get his id
					Console.WriteLine("Bobby has forgotten his ID at home, he will be placed at the back of the queue.");

					//Add bobby to back of queue
					queue.Enqueue(id);
				}
				else
				{
					//Display customer to screen
					Console.WriteLine($"{customer.Item1}\t{customer.Item2}\t\t{customer.Item3} seconds");
				}

				//Mutiple current looped customers processing time by 1000 and assign it into the processtime variable
				processtime = customer.Item3 * 1000;
			}
		}
	}
}
