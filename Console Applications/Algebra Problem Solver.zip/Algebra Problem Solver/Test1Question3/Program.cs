﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1Question3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Algebra Working
            //----------------------------------------------------------
            //Working out how much is left over after sides
            //money avaliable $80
            //6 sides, $10 for 3
            //10 x 2 = 20
            //80 - 20 = 60

            //Working out algebraic expression for pizza
            //pizza for $6 each
            //60 / 6 = p
            //60 / 6 = 10
            //----------------------------------------------------------

            //Variables
            int p = 10;
            int guess;

            //Intro Message
            Console.WriteLine("This program will get you to calculate an algebraic expression.\n----------------------------------------------------------------");

            try
            {
                //Get Users Input
                Console.Write("Please find the value of p.\n60 / 6 = p: ");
                guess = Convert.ToInt32(Console.ReadLine());

                //Compare guess to p and display message
                if (guess == p)
                    Console.WriteLine("Congrats {0} was the correct answer", guess);
                else if (guess != p)
                    Console.WriteLine("Sorry {0} was not the correct answer.", guess);
            }
            catch
            {
                //Display error message
                Console.WriteLine("an error has occured.");
            }

            //Inform the user of how to close the application
            Console.Write("Please press any key to close the application.");

            //await key press
            Console.ReadKey();
        }
    }
}
