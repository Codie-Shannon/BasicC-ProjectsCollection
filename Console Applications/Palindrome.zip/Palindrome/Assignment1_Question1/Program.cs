﻿using System;
using System.Collections;

namespace Assignment1_Question1
{
	class Program
	{
		//Variables
		static Stack stack = new Stack();

		static void Main(string[] args)
		{
			//This application was created by Codie Shannon
			//This application gets a word from the user, adds it to a stack, reverses the word, and checks if it is palindrome (the same backwards as it is forward)
			//Local variables
			string word;
			string reverseWord;
			string spacer = "===========================================================================================";

			//Inform user of purpose of application
			Console.WriteLine("This application will check if a entered word is palindrome (the same backwards as it is forward)");
			Console.WriteLine(spacer);

			//Get word from user
			Console.Write("Enter a word to check if it is a pandlindrome (the same backwards as it is forwards): ");
			word = Console.ReadLine();

			//Check if a word has been entered
			if (!string.IsNullOrEmpty(word))
			{
				//Format word
				word = word.ToLower();
				word = word.Replace(" ", "");

				//Add word to stack
				BuildWord(word);

				//Reverse word
				reverseWord = ReverseWord();

				//Check if the word is Palindrome (the same backwards as it is forward)
				PalindromeTest(word, reverseWord);
			}
			else
			{
				//Inform the user that no word was entered
				Console.WriteLine("No word was entered");
			}

			//Inform user of how to close the application
			Console.WriteLine(spacer);
			Console.Write("Please press any key to close the application.");

			//Await key press
			Console.ReadKey();
		}

		static void BuildWord(string word)
		{
			//Convert string to characvters array
			char[] characters = word.ToCharArray();

			//Loop through each character in the the characters array
			foreach (char character in characters)
			{
				//Push current looped character to stack
				stack.Push(character);
			}
		}

		static string ReverseWord()
		{
			//Initialize string
			string reverseWord = "";

			//Loop through stack
			while (stack.Count > 0)
			{
				//Get character from top of stack and assign it into reverseWord
				reverseWord += stack.Peek();

				//Remove top character from stack
				stack.Pop();
			}

			//Return the reversed word
			return reverseWord;
		}
		
		static void PalindromeTest(string word, string reverseWord)
		{
			//Check if the word is palindrome
			if(reverseWord == word)
			{
				//Inform user the word is a palindrome
				Console.WriteLine($"The word {word}, is a palindrome.");
			}
			else
			{
				//Inform user the word is not a palindrome
				Console.WriteLine($"{word} spelt backwards is {reverseWord}, that is not a palindrome.");
			}
		}
	}
}
