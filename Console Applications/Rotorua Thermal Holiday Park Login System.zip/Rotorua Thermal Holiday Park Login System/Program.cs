﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3Question1
{
    class Program
    {
        static void Main(string[] args)
        {
            //This program will ask the user to create new login credentials for the Rotorua Thermal Holiday Park Login System
            //The developer of this program is Codie Shannon

            //Variables
            bool validpassword;
            string spacer = "================================================================";

            //Welcome user to the login system
            Console.WriteLine("Welcome to the Rotorua Thermal Holiday Park Login System!");

            //Spacer
            Console.WriteLine(spacer);

            //Create login object and display message
            Login login1 = new Login();

            //Spacer
            Console.WriteLine(spacer);

            //Ask the user for a username
            Console.Write("Please enter a username (minimum of 5 characters): ");

            //Validate the username or get the user to enter a valid username using a while loop
            login1.validateUsername(Console.ReadLine());

            //Ask the user to enter a password and then re-enter the password for verification purposes
            validpassword = login1.validatePassword();

            //Spacer
            Console.WriteLine(spacer);

            //Return a message to the user depending on if the passwords match or not using a boolean value
            if (validpassword == true)
                Console.WriteLine("Passwords match, Login successful.");
            else
                Console.WriteLine("Passwords do not match, Login failed.");

            //Spacer
            Console.WriteLine(spacer);

            //Inform the user of how to exit the system
            Console.Write("Please press any key to exit the login system.");

            //Await key press
            Console.ReadKey();
        }
    }
}
