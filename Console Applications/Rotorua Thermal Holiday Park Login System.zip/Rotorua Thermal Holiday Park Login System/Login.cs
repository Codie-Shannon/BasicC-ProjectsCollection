﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3Question1
{
    class Login
    {
        //Variables
        private string str_userName;
        private string str_password;
        private string str_passwordverif;
        string spacer = "================================================================";

        public Login()
        {
            //Inform the user of applications purpose
            Console.WriteLine("Let's create a new Login, first I need some details from you...");
        }

        public void validateUsername(string str_username)
        {
            //Verify the username length is at least 5 characters long
            while (str_username.Length < 5)
            {
                //Inform the user that the username they have entered is not valid
                Console.WriteLine("Sorry that was not a valid username.");

                //Ask the user to enter a valid username that is at least 5 characters long
                Console.Write("Please enter a username (minimum of 5 characters): ");

                //Assign the users username in to the parameter
                str_username = Console.ReadLine();
            }

            //Spacer
            Console.WriteLine(spacer);

            //Assign the users username in to the instance variable
            str_userName = str_username;

            //Inform the user that the username is valid
            Console.WriteLine("Username valid.");
        }

        public bool validatePassword()
        {
            //Spacer
            Console.WriteLine(spacer);

            //Ask the user to enter a password
            Console.Write("Please enter a password: ");

            //Assign the users password in to the instance variable
            str_password = Console.ReadLine();

            //Spacer
            Console.WriteLine(spacer);

            //Ask the user to verify the password
            Console.Write("Please re-enter the password: ");

            //Assign the users verification password in to the instance variable
            str_passwordverif = Console.ReadLine();

            //Compare the passwords, if the passwords match return true and if the passwords dont match return false
            if (str_password == str_passwordverif)
                return true;
            else
                return false;
        }
    }
}
