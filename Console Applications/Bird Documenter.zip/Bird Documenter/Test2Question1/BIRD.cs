﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test2Question1
{
    class BIRD
    {
        //Variables
        private int WingspanID;
        private string BandNo;
        private string Name;
        private string Species;
        private string Sex;

        public BIRD(int wingspanID, string bandno)
        {
            //Assigning WingspanID and BandNo
            WingspanID = wingspanID;
            BandNo = bandno;

            //Writing Message To Screen
            Console.WriteLine("Bird object created and default data loaded...");
        }

        public void setName(string name)
        {
            //Assigning Name
            Name = name;
        }

        public void setSpecies(string species)
        {
            //Assigning Species
            Species = species;
        }

        public void setSex(string sex)
        {
            //Assigning Sex
            Sex = sex;
        }

        public void displayBird()
        {
            //Displaying information to user
            Console.WriteLine("Wingspan ID: {0}", WingspanID);
            Console.WriteLine("Band Number: {0}", BandNo);
            Console.WriteLine("Name: {0}", Name);
            Console.WriteLine("Species: {0}", Species);
            Console.WriteLine("Sex: {0}", Sex);
        }
    }
}
