﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test2Question1
{
    class Program
    {
        static void Main(string[] args)
        {
            //This application will get information about a bird and display it back to the user
            //Created by Codie Shannon

            //Inform user of applications purpose
            Console.WriteLine("This application will get information about a bird and display it back to you.");

            //Variables
            BIRD bird1 = new BIRD(20202123, "H39878");
            string spacer = "==============================================================================";

            //Spacer
            Console.WriteLine(spacer);

            //Get bird name from user
            Console.Write("Please enter the birds name: ");
            bird1.setName(Console.ReadLine());

            //Get bird species from user
            Console.Write("Please enter the birds species: ");
            bird1.setSpecies(Console.ReadLine());

            //Get bird sex from user
            Console.Write("Please enter the birds sex: ");
            bird1.setSex(Console.ReadLine());

            //Spacer
            Console.WriteLine(spacer);

            //Display bird information to user
            bird1.displayBird();

            //Spacer
            Console.WriteLine(spacer);

            //Inform user of how to close the application
            Console.Write("Please press any key to close the application.");

            //Awaiting key press
            Console.ReadKey();
        }
    }
}
