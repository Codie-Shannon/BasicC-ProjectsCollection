﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1Question2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Variables
            double[] userNums = new double[10];
            string[] numwords = new string[] { "1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th", "9th", "10th" };
            double total = 0;

            //Intro Message
            Console.WriteLine("This program will compute the average of ten numbers.\n-----------------------------------------------------");

            try
            {
                //Get Numbers From User
                for (int i = 0; i < userNums.Length; i++)
                {
                    Console.Write("Please enter the {0} number: ", numwords[i]);
                    userNums[i] = Convert.ToDouble(Console.ReadLine());
                    total += userNums[i];
                }

                //Display Average
                Console.WriteLine("The average of those ten numbers is: {0}", userNums.Average().ToString("00.0"));
            }
            catch (Exception e)
            {
                //Display Error Message
                Console.WriteLine("An error has occured.");
            }

            //Inform user of how to close the application
            Console.Write("Press any key to close the application.");

            //await key press
            Console.ReadKey();
        }
    }
}
