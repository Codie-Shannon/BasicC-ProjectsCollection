﻿using System;

namespace Assignment1_Question3
{
	class Program
	{
		static void Main(string[] args)
		{
			//This program was created by Codie Shannon
			//This program will take a sentence from the user split it into words, and utilizing a custom Enqueue and Dequeue method to display the words to the console
			//Create MyQueue Object
			MyQueue queue = new MyQueue();
			string sentence;
			string spacer = "==========================================================================================";

			//Inform user of applications purpose
			Console.WriteLine("The application will recieve a sentence and display the first word to the console.");
			Console.WriteLine(spacer);

			//Get sentence from user
			Console.Write("Enter a sentence: ");
			sentence = Console.ReadLine();

			//Split sentence into words and assign into string array
			string[] words = sentence.Split(' ');

			//Loop through words array
			foreach (string word in words)
			{
				//Add current looped word to queue
				queue.Enqueue(word);
			}

			//Get/Remove the top value in queue
			object value = queue.Dequeue();

			//Display value variable to screen
			Console.Write($"The first word in the sentence is {value}.\nThe remaining word(s) are ");

			//Loop through elements in queue
			while (queue.Length > 0)
			{
				//Remove top element from queue and display it to the console
				Console.Write(queue.Dequeue());

				//Check if the queue's length is above 1 or 1
				if (queue.Length > 1)
				{
					//Add comma to console
					Console.Write(", ");
				}
				else if (queue.Length == 1)
				{
					//Add comma and an and to console
					Console.Write(", and ");
				}
				else
				{
					//Add full stop to console
					Console.Write(".");
				}
			}

			//Inform user of how to close the application
			Console.WriteLine($"\n{spacer}");
			Console.Write("Please press any key to close the application.");

			//Await key presss
			Console.ReadKey();
		}
	}
}
