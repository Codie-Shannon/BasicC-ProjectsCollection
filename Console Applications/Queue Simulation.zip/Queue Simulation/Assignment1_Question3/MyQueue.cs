﻿using System.Collections;

namespace Assignment1_Question3
{
	public class MyQueue
	{
		//Instance variables
		private ArrayList Queue = new ArrayList();

		//Instance Properties
		public int Length { get { Queue.TrimToSize(); return Queue.Count; } }

		public void Enqueue(object value)
		{
			//Add value to Queue
			Queue.Add(value);
		}

		public object Dequeue()
		{
			//Get top value from queue
			var value = Queue[0];

			//Remove top value from queue
			Queue.RemoveAt(0);

			//Return value variable
			return value;
		}
	}
}
