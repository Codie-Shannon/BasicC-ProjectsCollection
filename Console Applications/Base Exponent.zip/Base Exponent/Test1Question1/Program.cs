﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1Question1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Variables
            int _base;
            int _exponent;
            int _result;

            //Intro Message
            Console.WriteLine("This program can give the result of base^exponent.\n--------------------------------------------------");

            try
            {
                //Get input from user
                Console.Write("Enter the value of the base number: ");
                _base = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter the value of the exponent: ");
                _exponent = Convert.ToInt32(Console.ReadLine());

                //Calculate Result
                _result = Convert.ToInt32(Math.Pow(_base, _exponent));

                //Display Result
                Console.WriteLine("{0}^{1} gives a result of: {2}", _base, _exponent, _result);
            }
            catch
            {
                //Display Error Message
                Console.WriteLine("An error has occured");
            }

            //Inform user of how to close the application
            Console.Write("Please press any key to close the application.");

            //await key press
            Console.ReadKey();
        }
    }
}
