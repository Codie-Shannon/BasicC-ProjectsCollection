﻿using System;

namespace Assignment1_Question2
{
	class Program
	{
		static void Main(string[] args)
		{
			//This program was created by Codie Shannon
			//This program will take a sentence such as Be Right Back and return the acronym
			//The program will do this by getting a sentence from the user, splitting the sentence into individual words, adding the words to a dictionary, and displaying it back to the console
			//Local variables
			string sentence;
			string spacer = "==================================================================================";

			//Inform user of purpose of application
			Console.WriteLine("The application will take a sentence such as Be Right Back and return the acronym.");
			Console.WriteLine(spacer);

			//Get sentence from user
			Console.Write("Enter a sentence to be converted to an acronym: ");
			sentence = Console.ReadLine();

			//Create new Acronym object and pass sentence string
			Acronym acronym = new Acronym(sentence);

			//Fill acronym dictionary with words from the sentence variable
			acronym.BuildAcronym();

			//Display acronym dictionary keys to screen
			acronym.DisplayAcronym();

			//Inform user of how to close the application
			Console.WriteLine(spacer);
			Console.Write("Please press any key to close the application.");

			//Await key press
			Console.ReadKey();
		}
	}
}
