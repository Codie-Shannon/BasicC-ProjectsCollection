﻿using System;
using System.Collections.Generic;

namespace Assignment1_Question2
{
	public class Acronym
	{
		//Instance Variables
		private string sentence;
		private string[] words;
		private Dictionary<char, string> acronymData = new Dictionary<char, string>();

		public Acronym(string _sentence)
		{
			//Assign passed _sentence variable into instance variable sentence
			sentence = _sentence;

			//Populate words array with the words within the sentence string
			words = sentence.Split(' ');
		}

		public void BuildAcronym()
		{
			//Loop through words array
			foreach (string word in words)
			{
				//Convert first character of word to uppercase and all of the following characters to lowercase
				//Source: https://www.dotnetperls.com/uppercase-first-letter
				string wordFmt = char.ToUpper(word[0]) + word.Substring(1).ToLower();

				//Get key
				char key = wordFmt[0];

				//Check if the acronymData dictionary's count is above 0, and check if the dictionary contains the value of key
				if (acronymData.Count > 0 && acronymData.ContainsKey(key))
				{
					//Convert key to lowercase
					key = char.ToLower(key);
				}

				//Add key and word to acronymData dictionary
				acronymData.Add(key, wordFmt);
			}
		}

		public void DisplayAcronym()
		{
			//Display message
			Console.Write("The acronym for this sentence is ");

			//Loop through keys in acronymData dictionary
			foreach (char key in acronymData.Keys)
			{
				//Convert current looped key to uppercase
				char _key = char.ToUpper(key);

				//Display current looped key in console
				Console.Write(_key);
			}

			//Add new line to console
			Console.WriteLine();
		}
	}
}
