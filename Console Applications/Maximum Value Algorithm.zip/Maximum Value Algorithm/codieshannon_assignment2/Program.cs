﻿using System;

namespace codieshannon_assignment2
{
	class Program
	{
		static void Main(string[] args)
		{
			// Program created by Codie Shannon
			// Assignment 2
			// =======================================================
			// Local variables
			Algorithm algorithm = new Algorithm();
			Random rand = new Random();
			int[] numbers = new int[100];
			int n, searchkey, occurance;

			// Other
			string questionNum = "Assignment 2 - Question ";
			string continueMsg = "Press any key to continue to assignment question ";
			string spacer = "=======================================================================================================================";


			// Generate Random Numbers
			// =======================================================
			// Loop through numbers array
			for (int i = 0; i < numbers.Length; i++)
			{
				// Generate a random number and assign it into current looped numbers array element
				numbers[i] = rand.Next(1, 100);
			}


			// Find Maximum
			// =======================================================
			// Inform the user of the assignment's question number
			Console.WriteLine($"{questionNum}1");

			// Display spacer
			Console.WriteLine(spacer);

			// Inform the user of the assignment questions purpose
			Console.WriteLine("This assignment question will ask the user for an amount of maximum numbers the user wants to display to the screen and display them.");

			// Display spacer
			Console.WriteLine(spacer);

			// Display array
			algorithm.Display(numbers);

			// Display spacer
			Console.WriteLine(spacer);

			// Get the number of maximum values to display to the screen from the user
			Console.Write("How many maximum values do you want to locate in the array to display to the screen (must be between 1 - 55)? ");
			int.TryParse(Console.ReadLine(), out n);

			// Display spacer
			Console.WriteLine(spacer);

			// Find n maximum numbers and display them to the screen
			algorithm.findMaximum(numbers, n);

			// Display spacer
			Console.WriteLine(spacer);

			// Inform the user to press any key to continue to the next assignment question
			Console.Write($"{continueMsg}2.");

			// Await key press
			Console.ReadKey();

			// Clear console
			Console.Clear();



			// Number Occurance Search
			// =======================================================
			// Inform the user of the assignment's question number
			Console.WriteLine($"{questionNum}2");

			// Display spacer
			Console.WriteLine(spacer);

			// Inform the user of the assignment questions purpose
			Console.WriteLine("This assignment question will ask the user for a value and the value occurance which the user wants to know the index of and display the located index back to the screen.");

			// Display spacer
			Console.WriteLine(spacer);

			// Display array
			algorithm.Display(numbers);

			// Display spacer
			Console.WriteLine(spacer);

			// Get the value the user wants to search for
			Console.Write("What value do you want to search for within the array? ");
			int.TryParse(Console.ReadLine(), out searchkey);

			// Display spacer
			Console.WriteLine(spacer);

			// Get the occurance the user wants to search for
			Console.Write("What occurance of the value do you want to search for within the array? ");
			int.TryParse(Console.ReadLine(), out occurance);

			// Display spacer
			Console.WriteLine(spacer);

			// Display the index of the occurance
			algorithm.NumOccuranceSearch(numbers, searchkey, occurance);

			// Display spacer
			Console.WriteLine(spacer);

			// Inform the user to press any key to continue to the next assignment question
			Console.Write($"{continueMsg}3.");

			// Await key press
			Console.ReadKey();

			// Clear console
			Console.Clear();



			// Last Occurance Search
			// =======================================================
			// Inform the user of the assignment's question number
			Console.WriteLine($"{questionNum}3");

			// Display spacer
			Console.WriteLine(spacer);

			// Inform the user of the assignment questions purpose
			Console.WriteLine("This assignment question will ask the user for a value and return the last occurrance of it within the array.");

			// Display spacer
			Console.WriteLine(spacer);

			// Display array
			algorithm.Display(numbers);

			// Display spacer
			Console.WriteLine(spacer);

			// Get search key from user
			Console.Write("What value do you want to search for within the array? ");
			int.TryParse(Console.ReadLine(), out searchkey);

			// Display spacer
			Console.WriteLine(spacer);

			// Get the last occurance of the searchkey value within the numbers array
			occurance = algorithm.LastOccuranceSearch(numbers, searchkey);

			// Check if a last occurance was found
			if (occurance != -1)
			{
				// Display index of the last occurance
				Console.WriteLine($"The value of {searchkey} has a last occurance index of: {occurance}");
			}
			else
			{
				// Inform the user that the entered value was not valid
				Console.WriteLine("The entered value was not valid.");
			}

			// Display spacer
			Console.WriteLine(spacer);

			// Inform the user to press any key to continue to the next assignment question
			Console.Write($"{continueMsg}4.");

			// Await key press
			Console.ReadKey();

			// Clear console
			Console.Clear();



			// Bubble Sort
			// =======================================================
			// Inform the user of the assignment's question number
			Console.WriteLine($"{questionNum}4");

			// Display spacer
			Console.WriteLine(spacer);

			// Inform the user of the assignment questions purpose
			Console.WriteLine("This assignment question will run a performance test between two different bubble sort methods on the below array.");

			// Display spacer
			Console.WriteLine(spacer);

			// Display array
			algorithm.Display(numbers);

			// Display spacer
			Console.WriteLine(spacer);

			// Run Bubble Sort
			algorithm.bubbleSort(numbers);

			// Display spacer
			Console.WriteLine(spacer);

			// Run Improved Bubble Sort
			algorithm.improvedBubbleSort(numbers);



			// Application Close
			// =======================================================
			// Display spacer
			Console.WriteLine(spacer);

			// Inform the user to press any key to close the application
			Console.Write("Press any key to close the application.");

			// Await key press
			Console.ReadKey();
		}
	}
}