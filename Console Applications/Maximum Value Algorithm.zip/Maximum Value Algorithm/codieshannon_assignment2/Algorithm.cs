﻿using System;
using System.Diagnostics;
using System.Linq;

namespace codieshannon_assignment2
{
	class Algorithm
	{
		// Instance Variables
		private static Stopwatch stopWatch = new Stopwatch();
		private int temp = 0;

		public void Display(int[] numbers)
		{
			// Display heading to screen
			Console.WriteLine("Initial Array");

			// Display spacer
			Console.WriteLine("=======================================================================================================================");

			// Loop through elements in numbers array
			for (int i = 0; i < numbers.Length; i++)
			{
				// Check if i is above 0
				if (i > 0)
				{
					// Display current looped numbers element to screen with comma
					Console.Write($", {numbers[i]}");
				}
				else
				{
					// Display current looped numbers element to screen
					Console.Write(numbers[i]);
				}
			}

			// Display new line
			Console.WriteLine();
		}

		public void findMaximum(int[] numbers, int n)
		{
			// Check if a valid value has been set for the n parameter
			if (n > 0 && n < 56)
			{
				// Initialize nums variable
				string nums = "";

				// Loop for the length of the n variable
				for (int outer = 0; outer < n; outer++)
				{
					// Assign 0 into the temp variable
					temp = 0;

					// Loop through numbers array
					for (int i = 0; i < numbers.Length; i++)
					{
						// Check if current looped numbers element is not contained within the nums variable
						// and check if the current looped numbers element is greater than the temp variable
						if (!nums.Contains($"{numbers[i]}") && numbers[i] > temp)
						{
							// Assign current looped numbers element into temp variable
							temp = numbers[i];
						}
					}

					// Amend (assign) temp variable to the end of the nums variable
					nums += $"{temp} ";
				}

				// Display nums variable to screen with header
				Console.WriteLine($"The {n} Maximum Value(s) Found Were: {nums}");
			}
			else if(n > 55)
			{
				// Inform the user that the entered value was too large
				Console.WriteLine("The value entered is too large.");
			}
			else
			{
				// Inform the user that the entered value was not valid
				Console.WriteLine("The value entered is not valid.");
			}
		}

		public void NumOccuranceSearch(int[] numbers, int searchkey, int occurance)
		{
			// Check if the occurance has been set and if the numbers array contains the occurance
			if (occurance != 0 && numbers.Count(i => i == searchkey) >= occurance)
			{
				// Assign 0 into the temp variable
				temp = 0;

				// Loop through numbers array
				for (int i = 0; i < numbers.Length; i++)
				{
					// Check if current looped numbers element is equal to the searchkey parameter
					if (numbers[i] == searchkey)
					{
						// Increase temp by 1
						temp++;
					}

					// Check if the temp variable is equal to the occurance parameter
					if (temp == occurance)
					{
						// Display occurance
						Console.WriteLine($"The value of {searchkey} has occurance {occurance} at index: {i}");

						// Return method
						return;
					}
				}
			}
			else
			{
				// Inform the user that the entered values were not valid
				Console.WriteLine("The entered values were not valid.");
			}
		}

		public int LastOccuranceSearch(int[] numbers, int searchkey)
		{
			// Check if the numbers array contains any matches for the searchkey
			if (numbers.Any(i => i == searchkey))
			{
				// Assign 0 into the temp variable
				temp = 0;

				// Loop through numbers array
				for (int i = 0; i < numbers.Length; i++)
				{
					// Check if current looped numbers element is equal to the searchkey parameter
					if (numbers[i] == searchkey)
					{
						// Assign i into temp variable
						temp = i;
					}
				}

				// Return the last occurance index of the searchkey variable
				return temp;
			}

			// Return null
			return -1;
		}

		public void bubbleSort(int[] numbers)
		{
			// Initialize data array
			int[] data = new int[100];

			// Copy numbers array into data array (Required in order to accurately test sort methods)
			Array.Copy(numbers, data, numbers.Length);

			// Restart stopWatch
			stopWatch.Restart();

			// Loop through the outer data array
			for (int outer = 0; outer < data.Length; outer++)
			{
				// Loop through the inner data array
				for (int i = 0; i < data.Length - 1; i++)
				{
					// Assign the data element which is one index infront of the current looped data element into the temp variable
					temp = data[i + 1];

					// Check if current looped data element is greater than the temp variable
					if (data[i] > temp)
					{
						// Swap numbers
						data[i + 1] = data[i];
						data[i] = temp;
					}
				}
			}

			// Stop stopWatch
			stopWatch.Stop();

			// Get elapsed time from stopWatch variable, format the elapsed time, and initialize the duration variable by assigning the elapsed time into it
			string duration = stopWatch.Elapsed.Duration().ToString("ss'.'fffffff");

			// Display sort time to screen
			Console.WriteLine($"Bubble Sort: {duration} seconds");
		}

		public void improvedBubbleSort(int[] numbers)
		{
			// Initialize data array
			int[] data = new int[100];

			// Copy numbers array into data array (Required in order to accurately test sort methods)
			Array.Copy(numbers, data, numbers.Length);

			// Initialize length variable by assigning the length of the data array into it
			int length = data.Length - 1;

			// Assign 0 into the temp variable
			temp = 0;

			// Restart stopWatch
			stopWatch.Restart();

			// Loop through the outer data array
			for (int outer = 0; outer < data.Length; outer++)
			{
				// Initialize isSwap variable
				bool isSwap = false;

				// Loop for the length of the length variable
				for (int i = 0; i < length; i++)
				{
					// Assign the data element which is one index infront of the current looped data element into the temp variable
					temp = data[i + 1];

					// Check if current looped data element is greater than the temp variable
					if (data[i] > temp)
					{
						// Swap numbers
						data[i + 1] = data[i];
						data[i] = temp;

						// Set isSwap variable to true
						isSwap = true;
					}
				}

				// Check if a swap has not occured
				if (isSwap == false)
				{
					// Stop loop
					break;
				}

				// Decrease length variable by 1 
				length--;
			}

			// Stop stopWatch
			stopWatch.Stop();

			// Get elapsed time from stopWatch variable, format the elapsed time, and initialize the duration variable by assigning the elapsed time into it
			string duration = stopWatch.Elapsed.Duration().ToString("ss'.'fffffff");

			// Display sort time to screen
			Console.WriteLine($"Improved Bubble Sort: {duration} seconds");
		}
	}
}